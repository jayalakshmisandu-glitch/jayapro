export default function MessageBubble({ message }) {
  return (
    <div className={`flex ${message.role === "user" ? "justify-end" : ""}`}>
      <div className={`p-3 rounded-xl max-w-md ${
        message.role === "user"
          ? "bg-indigo-600"
          : "bg-gray-700"
      }`}>
        {message.text}
      </div>
    </div>
  );
}