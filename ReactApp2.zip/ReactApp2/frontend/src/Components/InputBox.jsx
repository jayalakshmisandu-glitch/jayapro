import { useState } from "react";

export default function InputBox({ sendMessage }) {
  const [text, setText] = useState("");

  return (
    <div className="p-4 border-t border-gray-700 flex">
      <input
        className="flex-1 p-3 rounded bg-gray-800 outline-none"
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder="Ask something..."
      />

      <button
        className="ml-3 bg-indigo-600 px-5 rounded"
        onClick={() => {
          sendMessage(text);
          setText("");
        }}
      >
        Send
      </button>
    </div>
  );
}