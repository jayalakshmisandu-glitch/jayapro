export default function Sidebar() {
  return (
    <div className="w-64 bg-gray-800 p-4 hidden md:block">
      <h2 className="text-lg font-bold mb-4">AI Chat</h2>
      <button className="bg-indigo-600 w-full py-2 rounded">
        + New Chat
      </button>
    </div>
  );
}