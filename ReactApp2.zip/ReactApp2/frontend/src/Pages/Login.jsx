import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../Services/api";

export default function Login() {
  const [form, setForm] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const login = async () => {
    try {
      await api.post("/auth/login", form);
      navigate("/chat");
    } catch {
      alert("Invalid credentials");
    }
  };

  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100">
  <div className="bg-white p-8 rounded-2xl shadow-xl w-96 text-gray-800">
        <h2 className="text-2xl font-bold text-center mb-6">Welcome To AI Chat</h2>
<input
  className="w-full p-3 mb-3 rounded-lg bg-white/20 border border-white/30 
  text-black placeholder-gray-600 
  focus:outline-none focus:ring-2 focus:ring-indigo-400"
  placeholder="Email"
  onChange={e => setForm({ ...form, email: e.target.value })}
/>

<input
  type="password"
  className="w-full p-3 mb-4 rounded-lg bg-white/20 border border-white/30 
  text-black placeholder-gray-600 
  focus:outline-none focus:ring-2 focus:ring-indigo-400"
  placeholder="Password"
  onChange={e => setForm({ ...form, password: e.target.value })}
/>

        <button
          onClick={login}
          className="w-full bg-white text-indigo-700 font-semibold py-3 rounded hover:bg-gray-200"
        >
          Login
        </button>

        <p
          className="text-center mt-4 cursor-pointer underline"
          onClick={() => navigate("/signup")}
        >
          Create account
        </p>
      </div>
    </div>
  );
}