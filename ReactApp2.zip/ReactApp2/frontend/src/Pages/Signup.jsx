import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../Services/api";

export default function Signup() {
  const [form, setForm] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const signup = async () => {
    try {
      await api.post("/auth/signup", form);
      alert("Account created!");
      navigate("/");
    } catch {
      alert("Error creating account");
    }
  };

  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-br from-green-500 to-teal-600">
      <div className="backdrop-blur-lg bg-white/10 p-8 rounded-2xl shadow-xl w-96 text-white">
        <h2 className="text-2xl font-bold text-center mb-6">Create Account</h2>

        <input
          className="w-full p-3 mb-3 rounded bg-white/20"
          placeholder="Email"
          onChange={e => setForm({ ...form, email: e.target.value })}
        />

        <input
          type="password"
          className="w-full p-3 mb-4 rounded bg-white/20"
          placeholder="Password"
          onChange={e => setForm({ ...form, password: e.target.value })}
        />

        <button
          onClick={signup}
          className="w-full bg-white text-green-700 py-3 rounded"
        >
          Signup
        </button>

        <p
          className="text-center mt-4 cursor-pointer underline"
          onClick={() => navigate("/")}
        >
          Already have an account?
        </p>
      </div>
    </div>
  );
}