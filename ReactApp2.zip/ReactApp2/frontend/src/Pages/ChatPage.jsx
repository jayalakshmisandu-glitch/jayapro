import { useState } from "react";
import api from "../Services/api";
import Sidebar from "../Components/Sidebar";
import MessageBubble from "../Components/MessageBubble";
import InputBox from "../Components/InputBox";

export default function ChatPage() {
  const [messages, setMessages] = useState([]);

  const sendMessage = async (text) => {
    const newMessages = [...messages, { role: "user", text }];
    setMessages(newMessages);

    const res = await api.post("/chat/send", { message: text });

    // 🔥 Streaming effect
    let aiText = "";
    const full = res.data.response;

    for (let i = 0; i < full.length; i++) {
      aiText += full[i];

      setMessages([
        ...newMessages,
        { role: "ai", text: aiText }
      ]);

      await new Promise(r => setTimeout(r, 20));
    }
  };

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      <Sidebar />

      <div className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((m, i) => (
            <MessageBubble key={i} message={m} />
          ))}
        </div>

        <InputBox sendMessage={sendMessage} />
      </div>
    </div>
  );
}